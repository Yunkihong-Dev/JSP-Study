let $links = $(".link");
let $anss = $(".ans");
	$links.click(function(){
		$anss.toggleClass("on");
	});

