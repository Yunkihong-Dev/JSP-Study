package com.star.use;

public class UseFrontController {

}
