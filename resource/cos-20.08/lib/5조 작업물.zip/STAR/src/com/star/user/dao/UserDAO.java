package com.star.user.dao;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import com.star.mybatis.config.MyBatisConfig;

public class UserDAO {
public SqlSession sqlSession;

	public UserDAO() {
		sqlSession = MyBatisConfig.getSqlSessionFactory().openSession(true);
	}
	//이름바꾸기
	public void updateName(String userName, Long userNumber) {
		HashMap<String, Object> updateMap = new HashMap<String, Object>();
		updateMap.put("userName", userName);
		updateMap.put("userNumber", userNumber);
		sqlSession.update("user.updateName",updateMap);
	}
	//주소
	public void updateAddress(String userAddress, Long userNumber) {		
		HashMap<String, Object> updateMap = new HashMap<String, Object>();
		updateMap.put("userAddress", userAddress);
		updateMap.put("userNumber", userNumber);
		sqlSession.update("user.updateAddress",updateMap);
	}
	//폰번호	
	public void updatePhoneNumber(String userPhoneNumber, Long userNumber) {
		HashMap<String, Object> updateMap = new HashMap<String, Object>();
		updateMap.put("userPhoneNumber", userPhoneNumber);
		updateMap.put("userNumber", userNumber);
		sqlSession.update("user.updatePhoneNumber",updateMap);
	}
	//나이
	public void updateAge(int userAge, Long userNumber) {
		HashMap<Object, Object> updateMap = new HashMap<Object, Object>();
		updateMap.put("userAge", userAge);
		updateMap.put("userNumber", userNumber);
		sqlSession.update("user.updateAge",updateMap);
	}
//	//성
//	public void updateName(String userName, Long userNumber) {
//		HashMap<String, Object> updateMap = new HashMap<String, Object>();
//		updateMap.put("userName", userName);
//		updateMap.put("userNumber", userNumber);
//		sqlSession.update("user.updateName",updateMap);
//	}
//	//이메일
//	public void updateName(String userName, Long userNumber) {
//		HashMap<String, Object> updateMap = new HashMap<String, Object>();
//		updateMap.put("userName", userName);
//		updateMap.put("userNumber", userNumber);
//		sqlSession.update("user.updateName",updateMap);
//	}
	
	
}
