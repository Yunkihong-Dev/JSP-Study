package com.star.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.star.Result;
import com.star.user.controller.ChangeAddressOkController;
import com.star.user.controller.ChangeAgeOkController;
import com.star.user.controller.ChangeEmailOkController;
import com.star.user.controller.ChangeGenderOkController;
import com.star.user.controller.ChangeNameOkController;
import com.star.user.controller.ChangePhoneNumberOkController;
import com.star.user.controller.MyInfoOkController;

public class UserFrontController extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		String target = req.getRequestURI().replace(req.getContextPath() + "/", "").split("\\.")[0];
		Result result = null;
		System.out.println(target);
		System.out.println(req.getContextPath());
		if(target.equals("myInFoOk")) {
			result = new MyInfoOkController().execute(req, resp);
			
		}else if(target.equals("changeNameOk")) {
			result = new ChangeNameOkController().execute(req, resp);
			
		}else if(target.equals("changeAddressOk")) {
			result = new ChangeAddressOkController().execute(req, resp);
			
		}else if(target.equals("changePhoneNumberOk")) {
			result = new ChangePhoneNumberOkController().execute(req, resp);
			
		}else if(target.equals("changeAgeOk")) {
			result = new ChangeAgeOkController().execute(req, resp);
			
		}else if(target.equals("changeGenderOk")) {
			result = new ChangeGenderOkController().execute(req, resp);
			
		}else if(target.equals("changeEmailOk")) {
			result = new ChangeEmailOkController().execute(req, resp);
			
		}
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//여기까지 작업공간
		if(result != null) {
			if(result.isRedirect()) {
				resp.sendRedirect(result.getPath());
			}else {
				req.getRequestDispatcher(result.getPath()).forward(req, resp);
			}
		}
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
